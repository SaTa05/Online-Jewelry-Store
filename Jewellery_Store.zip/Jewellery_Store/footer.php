<!--Footer Part Start-->
<footer id="footerWrapper" class="clear">
	<!--Custom Column Start-->
	<div id="footer">
		<div class="column">
			<h3>Information</h3>
			<ul>
				<li><a href="about.php">About Us</a></li>
				<li><a href="delivery.html">Delivery Information</a></li>
				<li><a href="terms.html" target="_parent">Terms & Conditions</a></li>
			</ul>
		</div>
		<div class="column">
			<h3>Contact Info</h3>
			<ul>
				<li><a href="contact.php"><img src="image/mail.png" width="14px" height="14px"> Contact Us</a></li>
				<li><img src="image/phone.png" width="14px" height="14px"> 9876543210</li>
				<li><a href="#" onmouseover="showAddress();" onmouseout="hideAddress();">Address</a></li>
			</ul>
			<div id="AddressDiv" class="AddressDiv">
				<p><b>197 R. R. Plot</b></p>
				<p><b>Kolkata - 107</b></p>
			</div>
		</div>
		<div class="column">
			<h3>Extras</h3>
			<ul>
				<li onclick="showPromo();" onmouseover="hidePromo();">Special Promo</a></li>
			</ul>
		</div>
		<div class="column">
			<h3>History</h3>
			<ul>
				<li><a href="viewpurchase.php">Order</a></li>
			</ul>
		</div>
	</div>
	<!--Custom Column End-->

	<div class="powered-main">
		<div id="powered">
			<div class="fr">Copyright <a href="default.php">CP Jewellery</a> Your Online Store &copy; <?php /*$date = date("l, d F, Y");*/echo date("Y") ?></div>
			<div id="back-top" class="back-to-top"><a class="backtotop" href="javascript:void(0)"
					title="Back to Top"></a></div>
		</div>
	</div>

</footer>
<!--Footer Part End-->