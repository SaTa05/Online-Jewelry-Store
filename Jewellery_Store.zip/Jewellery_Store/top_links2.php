<!-- Top Part Start-->
<div class="top-links">
	<div class="links"> 
  		<a href="index-1.php">Home</a>|
    	<a href="cart.php">Shopping Cart</a>|
    	<a href="checkout.php">Checkout</a>|
    	<a href="viewpurchase.php" target="_blank">Order History</a>|
		<a href="#" onClick="showSearch();">Search</a>
	</div>
</div>
<!-- Top Part End-->